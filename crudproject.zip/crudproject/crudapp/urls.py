from django.urls import path
from crudapp import views # Import the views module from the current app

urlpatterns = [
    path('', views.home, name='home'), # Assuming you have a home view
    path('createtab/', views.create1, name='createtab'), # Create record URL
    path('success/', views.success, name='success'), # Success page URL
    path('readtab/', views.read, name='readtab'), # Read records URL
    path('<int:pk>/updatetab/', views.update, name='updatetab'), # Update record URL
    path('<int:pk>/deletetab/', views.delete, name='deletetab'), # Delete record URL
]
